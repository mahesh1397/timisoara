<?php
		require "dbconnection.php";
		$email=$_POST['email'];
		$query="insert into `subscribe`(`email`) values('".$email."')";
		$result=mysqli_query($con,$query);
		if($result)
		{
			header("location:index.php");
		}
		else
		{
			echo "subscription failed";
			header("loacation:index.php");
		}
?>