<?php
	$username="root";
	$pass="";
	$db="customers";
	$server="localhost";
	$con=mysqli_connect($server,$username,$pass,$db);
	
?>