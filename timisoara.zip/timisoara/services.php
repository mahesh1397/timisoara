<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">

<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <!-- Main Header-->
    <?php require "header.php";?>
    <!--End Main Header -->

    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/1.jpg);">
        <div class="auto-container">
            <!-- Animated Icons -->
            <div class="anim-icons">
                <span class="icon-1"></span>
                <span class="icon-2"></span>
                <span class="icon-3"></span>
                <span class="icon-4"></span>
                <span class="icon-5"></span>
                <span class="icon-6"></span>
                <span class="icon-7"></span>
                <span class="icon-8"></span>
                <span class="icon-9"></span>
            </div>
            
            <h1>Services</h1>
            <ul class="bread-crumb">
                <li><a href="index.html">Home </a></li>
                <li>Services</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->

    <!-- Feature Section -->
    <section class="feature-section alternate">
        <div class="auto-container">
            <div class="sec-title text-center">
                <span class="title">Features</span>
                <h2>What is really seo & how<br> can I use it?</h2>
            </div>

            <div class="features">
                <div class="row clearfix">
                    <!-- Feature Block -->
                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box wow fadeInLeft">
                            <div class="icon-box"><i class="flaticon-target-2"></i></div>
                            <h3><a href="project-detail.html">Market Research</a></h3>
                            <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches Organically</p>
                            <a href="project-detail.html" class="read-more">Read More</a>
                        </div>
                    </div>

                    <!-- Feature Block -->
                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box wow fadeInDown">
                            <div class="icon-box"><i class="flaticon-browser-3"></i></div>
                            <h3><a href="project-detail.html">Digital Marketing</a></h3>
                            <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches Organically</p>
                            <a href="project-detail.html" class="read-more">Read More</a>
                        </div>
                    </div>

                    <!-- Feature Block -->
                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box wow fadeInRight">
                            <div class="icon-box"><i class="flaticon-mail-1"></i></div>
                            <h3><a href="project-detail.html">Email Research</a></h3>
                            <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches Organically</p>
                            <a href="project-detail.html" class="read-more">Read More</a>
                        </div>
                    </div>

                    <!-- Feature Block -->
                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box wow fadeInLeft">
                            <div class="icon-box"><i class="flaticon-landing-page"></i></div>
                            <h3><a href="project-detail.html">Web Development</a></h3>
                            <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches Organically</p>
                            <a href="project-detail.html" class="read-more">Read More</a>
                        </div>
                    </div>

                    <!-- Feature Block -->
                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box wow fadeInUp">
                            <div class="icon-box"><i class="flaticon-touch-screen"></i></div>
                            <h3><a href="project-detail.html">Keyword Research</a></h3>
                            <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches Organically</p>
                            <a href="project-detail.html" class="read-more">Read More</a>
                        </div>
                    </div>

                    <!-- Feature Block -->
                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box wow fadeInRight">
                            <div class="icon-box"><i class="flaticon-rocket-1"></i></div>
                            <h3><a href="project-detail.html">Optimization</a></h3>
                            <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches Organically</p>
                            <a href="project-detail.html" class="read-more">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Feature Section -->

    <!-- News Section -->
    <section class="news-section alternate">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-md-4 col-sm-12 col-xs-12">
                    <div class="inner-column">
                        <div class="sec-title">
                            <span class="title">Blog</span>
                            <h2>Check what happening inside Timisoara</h2>
                            <div class="info">
                                <h4>Shared hosting</h4>
                                <ul>
                                    <li>By<a href="blog-classic.html"> Admin</a></li>
                                    <li><a href="blog-classic.html">Date 4 April 2018</a></li>
                                    <li><a href="blog-classic.html">Like 25</a></li>
                                    <li><a href="blog-classic.html">Comment  65</a></li>
                                </ul>
                            </div>
                            <p>Distinctively exploit optimal alignments for intuitive bandwidth. Quickly coordinate e-business through revolutionary catalysts for chang  the Seamlessly underwhelm optimal  processes.</p>
                        </div>
                    </div>
                </div>

                <div class="slider-column col-md-8 col-sm-12 col-xs-12">
                    <div class="inner-column wow fadeInRight">
                        <div class="single-item-carousel owl-carousel owl-theme">
                            <!-- Image Box -->
                            <div class="image-box">
                                <div class="image"><a href="blog-single.html"><img src="images/resource/news-3.png" alt=""></a></div>
                            </div>

                            <!-- Image Box -->
                            <div class="image-box">
                                <div class="image"><a href="blog-single.html"><img src="images/resource/news-3.png" alt=""></a></div>
                            </div>

                            <!-- Image Box -->
                            <div class="image-box">
                                <div class="image"><a href="blog-single.html"><img src="images/resource/news-3.png" alt=""></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End News Section -->

    <!--Clients Section-->
    <section class="clients-section">
        <div class="auto-container">
            <!--Sponsors Carousel-->
            <ul class="sponsors-carousel owl-carousel owl-theme">
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
            </ul>
        </div>
    </section>
    <!--End Clients Section-->

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="auto-container">
            <div class="sec-title text-center">
                <span class="title">Contact Us</span>
                <h2>We can help your business with <br> our knowledge</h2>
            </div>

            <div class="row clearfix">
                <div class="form-column col-md-6 col-sm-12 col-xs-12">
                    <div class="contact-form">
                        <form method="post" action="customer
						.php" id="contact-form">
                            <div class="form-group">
                                <input type="text" name="username" placeholder="Name" required="">
                            </div>
                            
                            <div class="form-group">
                                <input type="email" name="email" placeholder="Email" required="">
                            </div>

                            <div class="form-group">
                                <textarea name="message" placeholder="Your Message"></textarea>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="theme-btn btn-style-one">Send Message <i class="flaticon-play"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Contact Map -->
                <div class="map-column col-md-6 col-sm-12 col-xs-12">
                    <!--Map Outer-->
                    <div class="map-outer wow fadeInRight">
                        <!--Map Canvas-->
                        <div class="map-canvas"
                            data-zoom="1"
                            data-lat="-37.817085"
                            data-lng="144.955631"
                            data-type="roadmap"
                            data-hue="#ffc400"
                            data-title="Envato"
                            data-icon-path="images/icons/map-marker.png"
                            data-content="Melbourne VIC 3000, Australia<br><a href='mailto:info@youremail.com'>info@youremail.com</a>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Contact Section -->

    <!--Main Footer-->
    <?php require "footer.php";?>
    <!--End Main Footer-->

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-double-up"></span></div>
<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/knob.js"></script>
<script src="js/appear.js"></script>
<script src="js/validate.js"></script>
<script src="js/script.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="js/map-script.js"></script>
<!--End Google Map APi-->
</body>

<!-- Mirrored from t.commonsupport.com/timisoara/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 31 Oct 2019 06:28:47 GMT -->
</html>