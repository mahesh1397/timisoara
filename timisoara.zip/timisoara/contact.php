<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">

<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <!-- Main Header-->
    <?php require "header.php";?>
    <!--End Main Header -->

    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/1.jpg);">
        <div class="auto-container">
            <!-- Animated Icons -->
            <div class="anim-icons">
                <span class="icon-1"></span>
                <span class="icon-2"></span>
                <span class="icon-3"></span>
                <span class="icon-4"></span>
                <span class="icon-5"></span>
                <span class="icon-6"></span>
                <span class="icon-7"></span>
                <span class="icon-8"></span>
                <span class="icon-9"></span>
            </div>
            
            <h1>Contact US</h1>
            <ul class="bread-crumb">
                <li><a href="index.html">Home </a></li>
                <li>Contact US</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->

    <!-- Contact Section -->
    <section class="contact-section alternate">
        <div class="auto-container">
            <div class="sec-title text-center">
                <h2>We can help your business with <br> our knowledge</h2>
            </div>

            <div class="row clearfix">
                <div class="form-column col-md-6 col-sm-12 col-xs-12">
                    <div class="contact-form">
                        <form method="post" action="customer.php" id="contact-form">
                            <div class="form-group">
                                <input type="text" name="username" placeholder="Name" required="">
                            </div>
                            
                            <div class="form-group">
                                <input type="email" name="email" placeholder="Email" required="">
                            </div>

                            <div class="form-group">
                                <textarea name="message" placeholder="Your Message"></textarea>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="theme-btn btn-style-one">Send Message <i class="flaticon-play"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Contact Map -->
                <div class="map-column col-md-6 col-sm-12 col-xs-12">
                    <!--Map Outer-->
                    <div class="map-outer">
                        <!--Map Canvas-->
                        <div class="map-canvas"
                            data-zoom="1"
                            data-lat="-37.817085"
                            data-lng="144.955631"
                            data-type="roadmap"
                            data-hue="#ffc400"
                            data-title="Envato"
                            data-icon-path="images/icons/map-marker.png"
                            data-content="Melbourne VIC 3000, Australia<br><a href='mailto:info@youremail.com'>info@youremail.com</a>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Contact Section -->

    <!--Main Footer-->
		<?php require "footer.php";?>
        <!--Footer Bottom-->
        
    <!--End Main Footer-->

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-double-up"></span></div>
<script>
	function validate()
	{
		var mobile = document.getElementById("mob1").value;
		
		var phoneno = /^\d{10}$/;
  if((mobile.value.match(phoneno))
        {
      return true;
        }
      else
        {
			alert("hi");
        //document.getElementById("msg").innerHTML="Enter valid contact number";
        return false;
        }
	}
</script>
<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/knob.js"></script>
<script src="js/appear.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/validate.js"></script>
<script src="js/script.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="js/map-script.js"></script>
<!--End Google Map APi-->
</body>

<!-- Mirrored from t.commonsupport.com/timisoara/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 31 Oct 2019 06:29:40 GMT -->
</html>