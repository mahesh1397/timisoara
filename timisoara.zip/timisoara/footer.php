<html>
	<body>
		<footer class="main-footer">
        <!--footer upper-->
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Big Column-->
                    <div class="big-column col-md-5 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                            <!--Footer Column-->
                            <div class="footer-column col-md-8 col-sm-6 col-xs-12">
                                <div class="footer-widget logo-widget">
                                    <div class="logo">
                                        <a href="index.php"><font size="5px" style="font-family:roboto;">TECHNICAL BRILLIANCE</font></a>
                                    </div>
                                    <div class="text">Distinctively exploit optimal alignments for intuitive bandwidth. Quickly coordinate business through revolutionary</div>
                                    <div class="sign-img"><img src="images/resource/sign.png" alt=""></div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-4 col-sm-6 col-xs-12">
                                <div class="footer-widget links-widget">
                                    <h2>Quick Links</h2>
                                    <div class="widget-content">
                                        <ul class="list">
                                            <li><a href="about.php">About Us</a></li>
                                            <li><a href="services.php">Features</a></li>
                                           
                                            <li><a href="contact-2.php">Contact Us</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Big Column-->
                    <div class="big-column col-md-7 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                        
                            

                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget newsletter-widget">
                                    <h2>Subscribe</h2>
                                    <div class="newsletter-form">
                                        <form method="post" action="subscribe.php">
                                            <div class="form-group">
                                                <input type="email" name="email" value="" placeholder="Enter Your Email" required="">
                                                <button type="submit"><i class="flaticon-play"></i></button>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="social-links">
                                        <h2>Follow Us</h2>
                                        <ul class="social-icon-one">
                                            <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                            <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                            <li><a href="#"><span class="fa fa-youtube"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Footer Bottom-->
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="copyright clearfix">
                    <p>Copyright © 2019. All Rights Reserved By <a href="index.php">TECHNICAL BRILLIANCE</a></p>
                    <a href="contact.php" class="link"> Contact Us</a>
                </div>
            </div>
        </div>
    </footer>
	</body>
</html>