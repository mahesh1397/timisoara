<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">

<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <!-- Main Header-->
    <?php require "header.php";?>
    <!--End Main Header -->

    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/1.jpg);">
        <div class="auto-container">
            <!-- Animated Icons -->
            <div class="anim-icons">
                <span class="icon-1"></span>
                <span class="icon-2"></span>
                <span class="icon-3"></span>
                <span class="icon-4"></span>
                <span class="icon-5"></span>
                <span class="icon-6"></span>
                <span class="icon-7"></span>
                <span class="icon-8"></span>
                <span class="icon-9"></span>
            </div>
            
            <h1>Blog Single</h1>
            <ul class="bread-crumb">
                <li><a href="index.html">Home </a></li>
                <li>Blog Single</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->

    <!-- Sidebar Page Container -->
    <div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Content Side-->
                <div class="content-side col-lg-8 col-md-8 col-sm-12 col-xs-12">
                    <div class="news-detail style-two">
                        <!-- News Block -->
                        <div class="news-block">
                            <div class="inner-box">
                                <div class="image-box"><img src="images/resource/blog-6.jpg" alt=""></div>
                                <div class="lower-content">
                                    <h3>Deciphering Marketing Lingo For Small Business Owners</h3>
                                    <p>Just two good ol' boys Never mean no harm.  law since the day. Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation offshoring<br>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.</p>
                                    <p>Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple touchpoints for offshoring.</p>
                                    <p>Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps. Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom linecross-platform integration.</p>
                                    <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence without revolutionary ROI.</p>
                                    <blockquote>How sports fan clubs are the new sports fan clubs. How twitter can teach you about college baseball ranking.</blockquote>
                                    <p>Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple touchpoints for offshoring.</p>
                                    <p>Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps. Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom linecross-platform integration.Podcasting operational change management inside of workflows to establish a framework. Taking seamless key performance indicators offline to maximise the long tail. Keeping your eye on the ball while performing a deep dive on the start-up mentality to derive convergence on cross-platform integration.</p>
                                    <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. Dramatically visualize customer directed convergence without revolutionary ROI.</p>
                                    <p>Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions.</p>

                                    <div class="post-images">
                                        <div class="row clearfix">
                                            <div class="image col-md-6 col-sm-6 col-xs-12">
                                                <a href="images/resource/post-img-2.jpg" class="lightbox-image" data-fancybox="Gallery"><img src="images/resource/post-img-2.jpg" alt=" "></a>
                                            </div>
                                            <div class="image col-md-6 col-sm-6 col-xs-12">
                                                <a href="images/resource/post-img-3.jpg" class="lightbox-image" data-fancybox="Gallery"><img src="images/resource/post-img-3.jpg" alt=" "></a>
                                            </div>
                                            <div class="image col-md-12 col-sm-12 col-xs-12">
                                                <a href="images/resource/post-img-1.jpg" class="lightbox-image" data-fancybox="Gallery"><img src="images/resource/post-img-1.jpg" alt=" "></a>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Other Options -->
                                    <div class="post-share-options clearfix">
                                        <div class="pull-left">
                                            <p>Tags : </p>
                                            <ul class="tags">
                                                <li><a href="#">Business,</a></li>
                                                <li><a href="#">Design,</a></li>
                                                <li><a href="#">Marketing</a></li>
                                            </ul>             
                                        </div>
                                        <div class="pull-right">
                                            <p>Share : </p>
                                            <ul class="social-icon">
                                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                                <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--Comments Area-->
                        <div class="comments-area">
                            <div class="group-title"><h2>Comments (02)</h2></div>
                            
                            <div class="comments-box">
                                <div class="comment-box">
                                    <!-- Comment -->
                                    <div class="comment">
                                        <div class="author-thumb"><img src="images/resource/thumb-4.jpg" alt=""></div>
                                        <div class="comment-info">
                                            <h4 class="name">Peeter son</h4>
                                            <span class="date">April 16 2018</span>
                                        </div>
                                        <div class="text">Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar</div>
                                        <a href="#" class="reply-btn">Replay  <i class="flaticon-play"></i></a>
                                    </div>
                                </div>
                                <div class="comment-box">
                                    <!-- Comment -->
                                    <div class="comment">
                                        <div class="author-thumb"><img src="images/resource/thumb-5.jpg" alt=""></div>
                                        <div class="comment-info">
                                            <h4 class="name">Peeter son</h4>
                                            <span class="date">April 16 2018</span>
                                        </div>
                                        <div class="text">Podcasting operational change management inside of workflows to establish a framework. Taking seamless key performance indicators offline to maximise the long tail.</div>
                                        <a href="#" class="reply-btn">Replay  <i class="flaticon-play"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Comment Form -->
                        <div class="comment-form">
                            <div class="group-title"><h2>Leave a Reply</h2></div>

                            <div class="comments-form">
                                <form method="post" action="http://t.commonsupport.com/timisoara/blog.html">
                                    <div class="row clearfix">
                                        <div class="col-md-6 col-sm-12 col-xs-12 form-group">
                                            <input type="text" name="username" placeholder="Name" required>
                                        </div>
                                        
                                        <div class="col-md-6 col-sm-12 col-xs-12 form-group">
                                            <input type="email" name="email" placeholder="Mail" required>
                                        </div>
                                        
                                        <div class="col-md-12 col-sm-12 col-xs-12 form-group">
                                            <textarea name="message" placeholder="Your Comments"></textarea>
                                        </div>
                                        
                                        <div class="col-md-12 col-sm-12 col-xs-12 form-group">
                                            <button class="theme-btn btn-style-one" type="submit" name="submit-form">Post Comment <i class="flaticon-play"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <!--Comment Form-->

                        </div><!--End Comment Form -->

                    </div>
                </div>

                <!--Sidebar Side-->
                <div class="sidebar-side col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <aside class="sidebar">
                        <!-- Search Box -->
                        <div class="sidebar-widget search-box">
                            <div class="widget-content">
                                <form method="post" action="http://t.commonsupport.com/timisoara/blog.html">
                                    <div class="form-group">
                                        <input type="search" name="search-field" value="" placeholder="Search" required="">
                                        <button type="submit"><i class="flaticon-search-2"></i></button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- Post Widget -->
                        <div class="sidebar-widget post-widget">
                            <div class="sidebar-title"><h3>Latest Post</h3></div>
                            <div class="widget-content">
                                <!-- Post -->
                                <article class="post">
                                    <div class="thumb"><a href="event-single.html"><img src="images/resource/post-thumb-1.jpg" alt=""></a></div>
                                    <h3><a href="event-single.html">How Explore your Business Idea among Client</a></h3>
                                    <div class="date">April 16, 2018</div>
                                </article>

                                <!-- Post -->
                                <article class="post">
                                    <div class="thumb"><a href="event-single.html"><img src="images/resource/post-thumb-2.jpg" alt=""></a></div>
                                    <h3><a href="event-single.html">How Explore your Business Idea among Client</a></h3>
                                    <div class="date">April 16, 2018</div>
                                </article>

                                <!-- Post -->
                                <article class="post">
                                    <div class="thumb"><a href="event-single.html"><img src="images/resource/post-thumb-3.jpg" alt=""></a></div>
                                    <h3><a href="event-single.html">How Explore your Business Idea among Client</a></h3>
                                    <div class="date">April 16, 2018</div>
                                </article>

                                <!-- Post -->
                                <article class="post">
                                    <div class="thumb"><a href="event-single.html"><img src="images/resource/post-thumb-4.jpg" alt=""></a></div>
                                    <h3><a href="event-single.html">How Explore your Business Idea among Client</a></h3>
                                    <div class="date">April 16, 2018</div>
                                </article>
                            </div>
                        </div>

                        <!-- Category Widget -->
                        <div class="sidebar-widget categories">
                            <div class="sidebar-title"><h3>Categories</h3></div>
                            <ul class="category-list">
                                <li><a href="#">All</a></li>
                                <li><a href="#">Creative Agency    <span>(05)</span></a></li>
                                <li><a href="#">Design Course      <span>(10)</span></a></li>
                                <li><a href="#">Development          <span>(9)</span></a></li>
                                <li><a href="#">Business</a></li>
                            </ul>
                        </div>

                        <!-- Testimonial Widget -->
                        <div class="sidebar-widget qutoe-widget">
                            <div class="widget-content">
                                <blockquote style="background-image: url(images/resource/quote-bg.jpg);">
                                    <span class="icon fa fa-quote-left"></span>
                                    Just two good ol' boys Never mean no harm.  law since the day. Bring to the table win-win survival 
                                    <cite>-:Nattasha</cite>
                                </blockquote>
                            </div>
                        </div>

                        <!-- Tweets Widget-->
                        <div class="sidebar-widget tweets-widget">
                            <div class="sidebar-title"><h3>Latest Tweets</h3></div>
                            <!-- Tweet post -->
                            <div class="tweet-post">
                                <span class="icon"><i class=" fa fa-twitter"></i> @iPress tweets</span>
                                <p>Singolo is a free PSD template of a flat, single page <span>website created</span> by @T20 #freebie #psd</p>
                                <a href="#">http://bit.ly/<span>19XM8Lj</span></a>
                                <span class="time">2 hours ago</span>
                            </div> 

                            <!-- Tweet post -->
                            <div class="tweet-post">
                                <span class="icon"><i class=" fa fa-twitter"></i> @iPress tweets</span>
                                <p>Singolo is a free PSD template of a flat, single page <span>website created</span> by @T20 #freebie #psd</p>
                                <a href="#">http://bit.ly/<span>19XM8Lj</span></a>
                                <span class="time">2 hours ago</span>
                            </div> 
                        </div>

                        <!-- Popular tags -->
                        <div class="sidebar-widget tags-widget">
                            <div class="sidebar-title"><h3>New Tags</h3></div>
                            <ul class="tag-list clearfix">
                                <li><a href="#">Business</a></li>
                                <li><a href="#">Marketing</a></li>
                                <li><a href="#">SEO Analyses</a></li>
                                <li><a href="#">Marketing</a></li>
                                <li><a href="#">PHp</a></li>
                                <li><a href="#">Social</a></li>
                            </ul> 
                        </div>

                        <!-- Meta tags -->
                        <div class="sidebar-widget meta-widget">
                            <div class="sidebar-title"><h3>Meta</h3></div>
                            <ul class="meta-list">
                                <li><a href="#">Log in</a></li>
                                <li><a href="#">Entries <span>RSS</span></a></li>
                                <li><a href="#">Comments <span>RSS</span></a></li>
                                <li><a href="#">WordPress.org</a></li>
                            </ul> 
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </div>  
    <!-- End Sidebar Page Container -->

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="auto-container">
            <div class="sec-title text-center">
                <span class="title">Contact Us</span>
                <h2>We can help your business with <br> our knoledge</h2>
            </div>

            <div class="row clearfix">
                <div class="form-column col-md-6 col-sm-12 col-xs-12">
                    <div class="contact-form">
                        <form method="post" action="http://t.commonsupport.com/timisoara/sendemail.php" id="contact-form">
                            <div class="form-group">
                                <input type="text" name="username" placeholder="Name" required="">
                            </div>
                            
                            <div class="form-group">
                                <input type="email" name="email" placeholder="Email" required="">
                            </div>

                            <div class="form-group">
                                <textarea name="message" placeholder="Your Message"></textarea>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="theme-btn btn-style-one">Send Message <i class="flaticon-play"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Contact Map -->
                <div class="map-column col-md-6 col-sm-12 col-xs-12">
                    <!--Map Outer-->
                    <div class="map-outer">
                        <!--Map Canvas-->
                        <div class="map-canvas"
                            data-zoom="1"
                            data-lat="-37.817085"
                            data-lng="144.955631"
                            data-type="roadmap"
                            data-hue="#ffc400"
                            data-title="Envato"
                            data-icon-path="images/icons/map-marker.png"
                            data-content="Melbourne VIC 3000, Australia<br><a href='mailto:info@youremail.com'>info@youremail.com</a>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Contact Section -->

    <!--Main Footer-->
    <footer class="main-footer">
        <!--footer upper-->
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Big Column-->
                    <div class="big-column col-md-5 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                            <!--Footer Column-->
                            <div class="footer-column col-md-8 col-sm-6 col-xs-12">
                                <div class="footer-widget logo-widget">
                                    <div class="logo">
                                        <a href="index.html"><img src="images/footer-logo.png" alt="" /></a>
                                    </div>
                                    <div class="text">Distinctively exploit optimal alignments for intuitive bandwidth. Quickly coordinate business through revolutionary</div>
                                    <div class="sign-img"><img src="images/resource/sign.png" alt=""></div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-4 col-sm-6 col-xs-12">
                                <div class="footer-widget links-widget">
                                    <h2>Quick Links</h2>
                                    <div class="widget-content">
                                        <ul class="list">
                                            <li><a href="about.html">About Us</a></li>
                                            <li><a href="services.html">Features</a></li>
                                            <li><a href="project-full-width.html">Projects</a></li>
                                            <li><a href="blog-classic.html">Blog</a></li>
                                            <li><a href="contact-2.html">Contact Us</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Big Column-->
                    <div class="big-column col-md-7 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                        
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <!--Footer Column-->
                                <div class="footer-widget recent-posts">
                                    <h2 class="widget-title">Recent Posts</h2>
                                     <!--Footer Column-->
                                    <div class="widget-content">
                                        <div class="post">
                                            <h4><a href="blog-single.html">Top 10 SEO techniques for your site</a></h4>
                                            <span class="date"><i class="far fa-calendar-check"></i>4 April 2018</span>
                                        </div>

                                        <div class="post">
                                            <h4><a href="blog-single.html">Top 10 SEO techniques for your site</a></h4>
                                            <span class="date"><i class="far fa-calendar-check"></i>4 April 2018</span>
                                        </div>

                                        <div class="post">
                                            <h4><a href="blog-single.html">Top 10 SEO techniques for your site</a></h4>
                                            <span class="date"><i class="far fa-calendar-check"></i>4 April 2018</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget newsletter-widget">
                                    <h2>Subscribe</h2>
                                    <div class="newsletter-form">
                                        <form method="post" action="http://t.commonsupport.com/timisoara/contact.html">
                                            <div class="form-group">
                                                <input type="email" name="email" value="" placeholder="Enter Your Email" required="">
                                                <button type="submit"><i class="flaticon-play"></i></button>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="social-links">
                                        <h2>Follow Us</h2>
                                        <ul class="social-icon-one">
                                            <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                            <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                            <li><a href="#"><span class="fa fa-youtube"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Footer Bottom-->
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="copyright clearfix">
                    <p>Copyright © 2018. All Rights Reserved By <a href="index.html">Timisoara</a></p>
                    <a href="contact.html" class="link"> Contact Us</a>
                </div>
            </div>
        </div>
    </footer>
    <!--End Main Footer-->

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-double-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/knob.js"></script>
<script src="js/appear.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/validate.js"></script>
<script src="js/script.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="js/map-script.js"></script>
<!--End Google Map APi-->
</body>

<!-- Mirrored from t.commonsupport.com/timisoara/blog-single-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 31 Oct 2019 06:29:39 GMT -->
</html>