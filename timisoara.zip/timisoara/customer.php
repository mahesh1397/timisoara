<?php
	require "dbconnection.php";
	$name=$_POST['username'];
	$email=$_POST['email'];
	$msg=$_POST['message'];
	$date=date("Y-m-d");
	$query="INSERT INTO `customers`(`name`, `email`, `msg`,`date`) VALUES('".$name."','".$email."','".$msg."','".$date."')";
	$result=mysqli_query($con,$query);
	if($result)
	{
		header("location:index.php");
	}
	else
		echo "failed".mysqli_error();
?>