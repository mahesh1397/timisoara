<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">

<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="plugins/revolution/css/settings.css" rel="stylesheet" type="text/css"><!-- REVOLUTION SETTINGS STYLES -->
<link href="plugins/revolution/css/layers.css" rel="stylesheet" type="text/css"><!-- REVOLUTION LAYERS STYLES -->
<link href="plugins/revolution/css/navigation.css" rel="stylesheet" type="text/css"><!-- REVOLUTION NAVIGATION STYLES -->
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>
 	

    <!--End Main Header -->
		<?php require "header.php";?>
    <!--Main Slider-->
    <section class="main-slider main-slider-one">
        <div class="rev_slider_wrapper fullwidthbanner-container"  id="rev_slider_486_1_wrapper" data-source="gallery">
            <div class="rev_slider fullwidthabanner" id="rev_slider_486_1" data-version="5.4.1">
                <ul>
                    <!-- Slide 1 -->
                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1688" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/main-slider/image-1.jpg" data-title="Slide Title" data-transition="">
                        
                        <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/main-slider/image-1.jpg">

                         <div class="tp-caption tp-shape rs-parallaxlevel-4 tp-shapewrapper tp-resizeme big-ipad-hidden" 
                        data-basealign="slide"
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="shape"
                        data-height="auto"
                        data-whitespace="nowrap"
                        data-width="none"
                        data-hoffset="['0','0','0','0']"
                        data-voffset="['85','0','0','0']"
                        data-x="['right','right','right','right']"
                        data-y="['top','top','top','top']"
                        data-frames='[{"from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <figure class="content-image"><img src="images/main-slider/cloud.png" alt=""></figure>
                        </div>


                        <div class="tp-caption tp-resizeme big-ipad-hidden" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="shape"
                        data-height="none"
                        data-whitespace="nowrap"
                        data-width="none"
                        data-hoffset="['-80','0','0','0']"
                        data-voffset="['80','0','0','0']"
                        data-x="['left','left','left','left']"
                        data-y="['center','center','center','center']"
                        data-textalign="['top','top','top','top']"
                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <figure class="content-image"><img src="images/main-slider/content-image-2.png" alt=""></figure>
                        </div>

                        <div class="tp-caption tp-resizeme big-ipad-hidden" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="shape"
                        data-height="none"
                        data-whitespace="nowrap"
                        data-width="none"
                        data-hoffset="['302','0','0','0']"
                        data-voffset="['-215','0','0','0']"
                        data-x="['left','left','left','left']"
                        data-y="['center','center','center','center']"
                        data-textalign="['top','top','top','top']"
                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2800,"ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <figure class="content-image"><img src="images/main-slider/content-image-1.png" alt=""></figure>
                        </div>

                        <div class="tp-caption" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="text"
                        data-height="none"
                        data-whitespace="normal"
                        data-fontsize="['64','40','36','24']"
                        data-width="['430','800','630','480']"
                        data-hoffset="['0','15','15','15']"
                        data-voffset="['-70','-70','-90','-90']"
                        data-x="['right','left','left','left']"
                        data-y="['middle','middle','middle','middle']"
                        data-frames='[{"delay":0,"split":"chars","splitdelay":0.1,"speed":2000,"frame":"0","from":"x:[-105%];z:0;rX:0deg;rY:0deg;rZ:-90deg;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        	<h2>Website Development Agency</h2>
                        </div>
                        
                        <div class="tp-caption" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="text"
                        data-height="none"
                        data-whitespace="normal"
                        data-width="['430','630','630','480']"
                        data-hoffset="['0','15','15','15']"
                        data-voffset="['35','35','35','35']"
                        data-x="['right','left','left','left']"
                        data-y="['middle','middle','middle','middle']"
                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <div class="text">Provide all kind of seo services and help to improve seo ranking.Globally incubate standards compliant</div>
                        </div>
                        
                        <div class="tp-caption tp-resizeme" 
                        data-paddingbottom="[30,0,0,0]"
                        data-paddingleft="[10,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="text"
                        data-height="none"
                        data-whitespace="nowrap"
                        data-width="['430','420','420','480']"
                        data-hoffset="['20','15','15','15']"
                        data-voffset="['130','130','140','140']"
                        data-x="['right','left','left','left']"
                        data-y="['middle','middle','middle','middle']"
                        data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                        	<a href="about.php" class="theme-btn btn-style-one">Explore Now <i class="flaticon-play"></i></a>
                        </div>
                    </li>
                    
                    <!-- Slide 2 -->
                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1689" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/main-slider/image-1.jpg" data-title="Slide Title" data-transition="">
                        
                        <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/main-slider/image-3.jpg">

                         <div class="tp-caption tp-shape rs-parallaxlevel-4 tp-shapewrapper tp-resizeme big-ipad-hidden" 
                        data-basealign="slide"
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="shape"
                        data-height="auto"
                        data-whitespace="nowrap"
                        data-width="none"
                        data-hoffset="['0','0','0','0']"
                        data-voffset="['85','0','0','0']"
                        data-x="['right','right','right','right']"
                        data-y="['top','top','top','top']"
                        data-frames='[{"from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <figure class="content-image"><img src="images/main-slider/cloud.png" alt=""></figure>
                        </div>


                        <div class="tp-caption tp-resizeme big-ipad-hidden" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="shape"
                        data-height="none"
                        data-whitespace="nowrap"
                        data-width="none"
                        data-hoffset="['-80','0','0','0']"
                        data-voffset="['60','0','0','0']"
                        data-x="['left','left','left','left']"
                        data-y="['center','center','center','center']"
                        data-textalign="['top','top','top','top']"
                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <figure class="content-image"><img src="images/main-slider/content-image-5.png" alt=""></figure>
                        </div>

                        <div class="tp-caption" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="text"
                        data-height="none"
                        data-whitespace="normal"
                        data-fontsize="['64','40','36','24']"
                        data-width="['430','800','630','480']"
                        data-hoffset="['0','15','15','15']"
                        data-voffset="['-90','-90','-120','-120']"
                        data-x="['right','left','left','left']"
                        data-y="['middle','middle','middle','middle']"
                        data-frames='[{"delay":0,"split":"chars","splitdelay":0.1,"speed":2000,"frame":"0","from":"x:[-105%];z:0;rX:0deg;rY:0deg;rZ:-90deg;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        	<h2>What is seo & how can it help my buisness grow?</h2>
                        </div>
                        
                        <div class="tp-caption" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="text"
                        data-height="none"
                        data-whitespace="normal"
                        data-width="['430','630','630','480']"
                        data-hoffset="['0','15','15','15']"
                        data-voffset="['35','35','35','55']"
                        data-x="['right','left','left','left']"
                        data-y="['middle','middle','middle','middle']"
                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <div class="text">Provide all kind of seo services and help to improve seo ranking.Globally incubate standards compliant</div>
                        </div>
                        
                        <div class="tp-caption tp-resizeme" 
                        data-paddingbottom="[30,0,0,0]"
                        data-paddingleft="[10,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="text"
                        data-height="none"
                        data-whitespace="nowrap"
                        data-width="['430','420','420','480']"
                        data-hoffset="['20','15','15','15']"
                        data-voffset="['130','130','140','160']"
                        data-x="['right','left','left','left']"
                        data-y="['middle','middle','middle','middle']"
                        data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                        	<a href="about.html" class="theme-btn btn-style-one">Explore Now <i class="flaticon-play"></i></a>
                        </div>
                    </li>
                    
                    <!-- Slide 3 -->
                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1690" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/main-slider/image-1.jpg" data-title="Slide Title" data-transition="">
                        
                        <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/main-slider/image-4.jpg">

                         <div class="tp-caption tp-shape rs-parallaxlevel-4 tp-shapewrapper tp-resizeme big-ipad-hidden" 
                        data-basealign="slide"
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="shape"
                        data-height="auto"
                        data-whitespace="nowrap"
                        data-width="none"
                        data-hoffset="['0','0','0','0']"
                        data-voffset="['85','0','0','0']"
                        data-x="['right','right','right','right']"
                        data-y="['top','top','top','top']"
                        data-frames='[{"from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <figure class="content-image"><img src="images/main-slider/cloud.png" alt=""></figure>
                        </div>


                        <div class="tp-caption tp-resizeme big-ipad-hidden" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="shape"
                        data-height="none"
                        data-whitespace="nowrap"
                        data-width="none"
                        data-hoffset="['-80','0','0','0']"
                        data-voffset="['60','0','0','0']"
                        data-x="['left','left','left','left']"
                        data-y="['center','center','center','center']"
                        data-textalign="['top','top','top','top']"
                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <figure class="content-image"><img src="images/main-slider/content-image-6.png" alt=""></figure>
                        </div>

                        <div class="tp-caption" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="text"
                        data-height="none"
                        data-whitespace="normal"
                        data-fontsize="['64','40','36','24']"
                        data-width="['430','800','630','480']"
                        data-hoffset="['0','15','15','15']"
                        data-voffset="['-90','-90','-120','-120']"
                        data-x="['right','left','left','left']"
                        data-y="['middle','middle','middle','middle']"
                        data-frames='[{"delay":0,"split":"chars","splitdelay":0.1,"speed":2000,"frame":"0","from":"x:[-105%];z:0;rX:0deg;rY:0deg;rZ:-90deg;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        	<h2>Digital Agency That Help You To Go Ahead</h2>
                        </div>
                        
                        <div class="tp-caption" 
                        data-paddingbottom="[0,0,0,0]"
                        data-paddingleft="[0,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="text"
                        data-height="none"
                        data-whitespace="normal"
                        data-width="['430','630','630','480']"
                        data-hoffset="['0','15','15','15']"
                        data-voffset="['35','35','35','55']"
                        data-x="['right','left','left','left']"
                        data-y="['middle','middle','middle','middle']"
                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                            <div class="text">Provide all kind of seo services and help to improve seo ranking.Globally incubate standards compliant</div>
                        </div>
                        
                        <div class="tp-caption tp-resizeme" 
                        data-paddingbottom="[30,0,0,0]"
                        data-paddingleft="[10,0,0,0]"
                        data-paddingright="[0,0,0,0]"
                        data-paddingtop="[0,0,0,0]"
                        data-responsive_offset="on"
                        data-type="text"
                        data-height="none"
                        data-whitespace="nowrap"
                        data-width="['430','420','420','480']"
                        data-hoffset="['20','15','15','15']"
                        data-voffset="['130','130','140','160']"
                        data-x="['right','left','left','left']"
                        data-y="['middle','middle','middle','middle']"
                        data-frames='[{"from":"x:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                        	<a href="about.html" class="theme-btn btn-style-one">Explore Now <i class="flaticon-play"></i></a>
                        </div>
                    </li>
                    
                </ul>
            </div>
        </div>
    </section>
    <!--End Main Slider-->
    
    <!-- About Us -->
    <section class="about-us">
        <span class="float-text">about</span>
        <div class="auto-container">
            <div class="row clearfix">
                <div class="title-column col-md-6 col-sm-12 col-xs-12">
                    <div class="inner-column">
                        <div class="sec-title">
                            <span class="title">About Us</span>
                            <h2>We are a dynamic team of creatives people of design, marketing, web & apps development.</h2>
                        </div>                
                    </div>
                </div>

                <!-- Text Column -->
                <div class="text-column col-md-6 col-sm-12 col-xs-12">
                    <div class="inner-column">
                        <p>
							We are fully-integrated, 100% employee-owned agency with fierce beliefs and a unifying culture.our clients describe us as "happily feisty" because we work tirelessly to make them successful.
							We use our collective creativity to make a positive impact on business, on culture and on the well-being of others. While advertising is our craft, our effect is much, much bigger. We’ve changed the way people view grocery shopping, how people buy cars, how people plan vacations, how people gather around sports, and the way people think about money...the list is long. Our culture is based on the fundamental belief that we are stronger as a whole and that together, we can give rise to change.
						</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Us -->

    <!-- Feature Section -->
    <section class="feature-section">
        <div class="auto-container">
            <div class="sec-title text-center">
                <span class="title">Features</span>
                <h2>What is really seo & how<br> can I use it?</h2>
            </div>

            <div class="features">
                <div class="row clearfix">
                    <!-- Feature Block -->
                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box wow fadeInLeft">
                            <div class="icon-box"><i class="flaticon-target-2"></i></div>
                            <h3><a href="project-detail.html">Market Research</a></h3>
                            <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches Organically</p>
                            
                        </div>
                    </div>

                    <!-- Feature Block -->
                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box wow fadeInUp">
                            <div class="icon-box"><i class="flaticon-browser-3"></i></div>
                            <h3><a href="project-detail.html">Digital Marketing</a></h3>
                            <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches Organically</p>
                            
                        </div>
                    </div>

                    <!-- Feature Block -->
                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                        <div class="inner-box wow fadeInRight">
                            <div class="icon-box"><i class="flaticon-mail-1"></i></div>
                            <h3><a href="project-detail.html">Email Research</a></h3>
                            <p>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches Organically</p>
                            
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- Feature Section -->

     <!--Fluid Section One-->
    <section class="fluid-section-one">
        <div class="outer-container clearfix">

            <!--Image Column-->
            <div class="image-column wow fadeInLeft" style="background-image:url(images/resource/image-1.png);">
                <figure class="image-box"><img src="images/resource/image-1.png" alt=""></figure>
            </div>

            <!--Content Column-->
            <div class="content-column">
                <div class="inner-column">
                    <div class="sec-title"> 
                        <span class="title">What we do ?</span>
                        <h2>You may <br>ask what SEO is <br>and why do you need it?</h2>
                    </div>
                    <div class="content">
                        <p>Distinctively exploit optimal alignments for intuitive bandwidth. Quickly coordinate e-business applications through revolutionary catalysts for chang  the Seamlessly underwhelm optimal testing procedures.</p>

                        <ul class="services-list">
                            <li>
                                <div class="icon-box"><span class="flaticon-global"></span></div>
                                <h4><a href="project-detail.html">Social Media Marketing</a></h4>
                                <p>Business applications through revolutionary catalysts for chang  the Seamlessly underwhelm dures</p>
                            </li>

                            <li>
                                <div class="icon-box"><span class="flaticon-mail-2"></span></div>
                                <h4><a href="project-detail.html">Email Marketing</a></h4>
                                <p>Business applications through revolutionary catalysts for chang  the Seamlessly underwhelm dures</p>
                            </li>

                            <li>
                                <div class="icon-box"><span class="flaticon-landing-page"></span></div>
                                <h4><a href="project-detail.html">SEO Optimization</a></h4>
                                <p>Business applications through revolutionary catalysts for chang  the Seamlessly underwhelm dures</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Fluid Section -->

    

    <!-- Project Section -->
    <!--<section class="project-section">
        <div class="outer-container">
            <div class="sec-title text-center">
                <span class="title">Work</span>
                <h2>Our Project</h2>
            </div>

            <div class="row clearfix">
                <!-- Project Block -->
                <!--<div class="project-block col-md-4 col-sm-6 col-xs-12">
                    <div class="image-box wow fadeInLeft">
                        <figure><img src="images/gallery/1.jpg" alt=""></figure>
                        <div class="overlay-box">
                            <div class="content">
                                <span>Branding</span>
                                <h4><a href="project-detail.html">Home Decoration</a></h4>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <!--<div class="project-block col-md-4 col-sm-6 col-xs-12">
                    <div class="image-box wow fadeInDown">
                        <figure><img src="images/gallery/2.jpg" alt=""></figure>
                        <div class="overlay-box">
                            <div class="content">
                                <span>Branding</span>
                                <h4><a href="project-detail.html">Home Decoration</a></h4>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <!--<div class="project-block col-md-4 col-sm-6 col-xs-12">
                    <div class="image-box wow fadeInRight">
                        <figure><img src="images/gallery/3.jpg" alt=""></figure>
                        <div class="overlay-box">
                            <div class="content">
                                <span>Branding</span>
                                <h4><a href="project-detail.html">Home Decoration</a></h4>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <!--<div class="project-block col-md-4 col-sm-6 col-xs-12">
                    <div class="image-box wow fadeInLeft">
                        <figure><img src="images/gallery/4.jpg" alt=""></figure>
                        <div class="overlay-box">
                            <div class="content">
                                <span>Branding</span>
                                <h4><a href="project-detail.html">Home Decoration</a></h4>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <!--<div class="project-block col-md-4 col-sm-6 col-xs-12">
                    <div class="image-box wow fadeInUp">
                        <figure><img src="images/gallery/5.jpg" alt=""></figure>
                        <div class="overlay-box">
                            <div class="content">
                                <span>Branding</span>
                                <h4><a href="project-detail.html">Home Decoration</a></h4>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <!--<div class="project-block col-md-4 col-sm-6 col-xs-12">
                    <div class="image-box wow fadeInRight">
                        <figure><img src="images/gallery/6.jpg" alt=""></figure>
                        <div class="overlay-box">
                            <div class="content">
                                <span>Branding</span>
                                <h4><a href="project-detail.html">Home Decoration</a></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Btn box -->
            <!--<div class="btn-box text-center">
                <a href="project-grid.html" class="theme-btn btn-style-one wow tada">More work <i class="flaticon-play"></i></a>
            </div>
        </div>
    </section>-->
    <!--End Project Section -->

    <!-- Pricing Section -->
    <section class="pricing-section">
        <div class="auto-container">

            <div class="tabs-box">
                
                <div class="row clearfix">
                    <div class="content-column pull-right col-md-4 col-sm-12 col-xs-12">
                        <div class="inner-column">
                            <div class="sec-title">
                                <span class="title">Price</span>
                                <h2>Not any hidden charge, Choose Your pricing plan</h2>
                            </div>
                            <ul class="tab-buttons btn-box">
                                <li data-tab="#pricing-tab-1" class="tab-btn active-btn">Monthly</li>
                                <li data-tab="#pricing-tab-2" class="tab-btn">Yearly</li>
                            </ul>
                            <p>Distinctively exploit optimal alignments for intuitive bandwidth. Quickly coordinate e-business through revolutionary catalysts for chang  the Seamlessly underwhelm optimal testing procedures whereas processes.Synergistically evolve 2.0 technologies rather than just inhighly efficient manufactured products and enabled data.</p>
                        </div>
                    </div>

                    <div class="table-column col-md-8 col-sm-12 col-xs-12">
                        <div class="inner-column tabs-content">
                            <div class="tab active-tab" id="pricing-tab-1">
                                <div class="row clearfix">
                                    <!-- Pricing Table -->
                                    <div class="pricing-table col-md-6 col-sm-6 col-xs-12">
                                        <div class="inner-box wow fadeInDown">
                                            <div class="table-header">
                                                <span>Free</span>
                                                <p>Monthly Package</p>
                                                <h3 class="price"><sup>$</sup>49.9</h3>
                                            </div>
                                            <div class="table-content">
                                                <ul>
                                                    <li>50GB Bandwidth</li>
                                                    <li>Business & <span>Financ</span> Analysing</li>
                                                    <li>24 hour support</li>
                                                    <li><span>Customer</span> Managemet</li>
                                                </ul>
                                            </div>
                                            <div class="table-footer">
                                                <a href="contact.html" class="theme-btn btn-style-two">Sign Up</a>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Pricing Table -->
                                    <div class="pricing-table col-md-6 col-sm-6 col-xs-12">
                                        <div class="inner-box wow fadeInUp">
                                            <div class="table-header">
                                                <span>Free</span>
                                                <p>Monthly Package</p>
                                                <h3 class="price"><sup>$</sup>65.90</h3>
                                            </div>
                                            <div class="table-content">
                                                <ul>
                                                    <li>50GB Bandwidth</li>
                                                    <li>Business & <span>Financ</span> Analysing</li>
                                                    <li>24 hour support</li>
                                                    <li><span>Customer</span> Managemet</li>
                                                </ul>
                                            </div>
                                            <div class="table-footer">
                                                <a href="contact.html" class="theme-btn btn-style-two">Sign Up</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="tab" id="pricing-tab-2">
                                <div class="row clearfix">
                                    <!-- Pricing Table -->
                                    <div class="pricing-table col-md-6 col-sm-6 col-xs-12">
                                        <div class="inner-box">
                                            <div class="table-header">
                                                <span>Free</span>
                                                <p>Monthly Package</p>
                                                <h3 class="price"><sup>$</sup>100.00</h3>
                                            </div>
                                            <div class="table-content">
                                                <ul>
                                                    <li>50GB Bandwidth</li>
                                                    <li>Business & <span>Financ</span> Analysing</li>
                                                    <li>24 hour support</li>
                                                    <li><span>Customer</span> Managemet</li>
                                                </ul>
                                            </div>
                                            <div class="table-footer">
                                                <a href="contact.html" class="theme-btn btn-style-two">Sign Up</a>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Pricing Table -->
                                    <div class="pricing-table col-md-6 col-sm-6 col-xs-12">
                                        <div class="inner-box">
                                            <div class="table-header">
                                                <span>Basic</span>
                                                <p>Monthly Package</p>
                                                <h3 class="price"><sup>$</sup>130.00</h3>
                                            </div>
                                            <div class="table-content">
                                                <ul>
                                                    <li>50GB Bandwidth</li>
                                                    <li>Business & <span>Financ</span> Analysing</li>
                                                    <li>24 hour support</li>
                                                    <li><span>Customer</span> Managemet</li>
                                                </ul>
                                            </div>
                                            <div class="table-footer">
                                                <a href="contact.html" class="theme-btn btn-style-two">Sign Up</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Pricing Section -->

    <!-- Fun Fact -->
    <section class="fun-fact-section">
        <div class="auto-container">
            <div class="fact-counter">
                <div class="row clearfix">
                    <!-- Counter Box -->
                    <div class="counter-box col-md-3 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="graph-outer">
                                <input type="text" class="dial" data-fgColor="#ff4b4b" data-bgColor="#ffffff" data-width="120" data-height="120" data-linecap="1"  value="95">
                                <div class="inner-text count-box"><span class="count-text txt" data-stop="95" data-speed="2000"></span></div>
                            </div>
                            <h3>Happy Customers</h3>
                        </div>
                    </div>

                    <!-- Counter Box -->
                    <div class="counter-box col-md-3 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="graph-outer">
                                <input type="text" class="dial" data-fgColor="#ff4b4b" data-bgColor="#ffffff" data-width="120" data-height="120" data-linecap="1"  value="80">
                                <div class="inner-text count-box"><span class="count-text txt" data-stop="80" data-speed="2000"></span></div>
                            </div>
                            <h3>Professionals</h3>
                        </div>
                    </div>

                    <!-- Counter Box -->
                    <div class="counter-box col-md-3 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="graph-outer">
                                <input type="text" class="dial" data-fgColor="#ff4b4b" data-bgColor="#ffffff" data-width="120" data-height="120" data-linecap="1"  value="83">
                                <div class="inner-text count-box"><span class="count-text txt" data-stop="83" data-speed="2000"></span></div>
                            </div>
                            <h3>Customers</h3>
                        </div>
                    </div>

                    <!-- Counter Box -->
                    <div class="counter-box col-md-3 col-sm-6 col-xs-12">
                        <div class="inner-box">
                            <div class="graph-outer">
                                <input type="text" class="dial" data-fgColor="#ff4b4b" data-bgColor="#ffffff" data-width="120" data-height="120" data-linecap="1"  value="76">
                                <div class="inner-text count-box"><span class="count-text txt" data-stop="76" data-speed="2000"></span></div>
                            </div>
                            <h3>Progress</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Fun Fact -->

    
    <!--Main Footer-->
		<?php require "footer.php";?>
    <!--End Main Footer-->

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-double-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script>
<!--Revolution Slider-->
<script src="plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="js/main-slider-script.js"></script>
<!--End Revolution Slider-->
<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/knob.js"></script>
<script src="js/appear.js"></script>
<script src="js/validate.js"></script>
<script src="js/script.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="js/map-script.js"></script>
<!--End Google Map APi-->
</body>

<!-- Mirrored from t.commonsupport.com/timisoara/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 31 Oct 2019 06:27:11 GMT -->
</html>