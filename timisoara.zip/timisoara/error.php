<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="utf-8">

<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <!-- Main Header-->
    <?php require "header.php";?>
    <!--End Main Header -->

    <!--Page Title-->
    <section class="page-title" style="background-image:url(images/background/1.jpg);">
        <div class="auto-container">
            <!-- Animated Icons -->
            <div class="anim-icons">
                <span class="icon-1"></span>
                <span class="icon-2"></span>
                <span class="icon-3"></span>
                <span class="icon-4"></span>
                <span class="icon-5"></span>
                <span class="icon-6"></span>
                <span class="icon-7"></span>
                <span class="icon-8"></span>
                <span class="icon-9"></span>
            </div>
            
            <h1>Error Page</h1>
            <ul class="bread-crumb">
                <li><a href="index.html">Home </a></li>
                <li>Error Page</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->

    <!--Error Section-->
    <section class="error-section">
        <div class="auto-container">
            <figure class="wow slideInUp" data-wow-delay="0ms" data-wow-duration="2000ms"><img src="images/resource/error-image.png" alt=""></figure>
            <h2>Opps!! Page Not Found</h2>
            <p>The page you are looking for was removed or might never existed.</p>
            <a href="index.html" class="theme-btn btn-style-one">Go To Home <i class="flaticon-play"></i></a>
            <!-- Bottom Image -->
        </div>
    </section>
    <!--End Error Section-->

    <!--Main Footer-->
    <footer class="main-footer">
        <!--footer upper-->
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Big Column-->
                    <div class="big-column col-md-5 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                            <!--Footer Column-->
                            <div class="footer-column col-md-8 col-sm-6 col-xs-12">
                                <div class="footer-widget logo-widget">
                                    <div class="logo">
                                        <a href="index.html"><img src="images/footer-logo.png" alt="" /></a>
                                    </div>
                                    <div class="text">Distinctively exploit optimal alignments for intuitive bandwidth. Quickly coordinate business through revolutionary</div>
                                    <div class="sign-img"><img src="images/resource/sign.png" alt=""></div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-4 col-sm-6 col-xs-12">
                                <div class="footer-widget links-widget">
                                    <h2>Quick Links</h2>
                                    <div class="widget-content">
                                        <ul class="list">
                                            <li><a href="about.html">About Us</a></li>
                                            <li><a href="services.html">Features</a></li>
                                            <li><a href="project-full-width.html">Projects</a></li>
                                            <li><a href="blog-classic.html">Blog</a></li>
                                            <li><a href="contact-2.html">Contact Us</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Big Column-->
                    <div class="big-column col-md-7 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                        
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <!--Footer Column-->
                                <div class="footer-widget recent-posts">
                                    <h2 class="widget-title">Recent Posts</h2>
                                     <!--Footer Column-->
                                    <div class="widget-content">
                                        <div class="post">
                                            <h4><a href="blog-single.html">Top 10 SEO techniques for your site</a></h4>
                                            <span class="date"><i class="far fa-calendar-check"></i>4 April 2018</span>
                                        </div>

                                        <div class="post">
                                            <h4><a href="blog-single.html">Top 10 SEO techniques for your site</a></h4>
                                            <span class="date"><i class="far fa-calendar-check"></i>4 April 2018</span>
                                        </div>

                                        <div class="post">
                                            <h4><a href="blog-single.html">Top 10 SEO techniques for your site</a></h4>
                                            <span class="date"><i class="far fa-calendar-check"></i>4 April 2018</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget newsletter-widget">
                                    <h2>Subscribe</h2>
                                    <div class="newsletter-form">
                                        <form method="post" action="http://t.commonsupport.com/timisoara/contact.html">
                                            <div class="form-group">
                                                <input type="email" name="email" value="" placeholder="Enter Your Email" required="">
                                                <button type="submit"><i class="flaticon-play"></i></button>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="social-links">
                                        <h2>Follow Us</h2>
                                        <ul class="social-icon-one">
                                            <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                            <li><a href="#"><span class="fa fa-instagram"></span></a></li>
                                            <li><a href="#"><span class="fa fa-youtube"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Footer Bottom-->
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="copyright clearfix">
                    <p>Copyright © 2018. All Rights Reserved By <a href="index.html">Timisoara</a></p>
                    <a href="contact.html" class="link"> Contact Us</a>
                </div>
            </div>
        </div>
    </footer>
    <!--End Main Footer-->

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-double-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/knob.js"></script>
<script src="js/appear.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/validate.js"></script>
<script src="js/script.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="js/map-script.js"></script>
<!--End Google Map APi-->
</body>

<!-- Mirrored from t.commonsupport.com/timisoara/error.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 31 Oct 2019 06:29:40 GMT -->
</html>